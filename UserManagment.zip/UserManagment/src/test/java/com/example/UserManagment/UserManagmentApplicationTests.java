package com.example.UserManagment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
